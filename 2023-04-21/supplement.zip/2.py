from gilp import LP
from gilp import simplex_visual

lp = LP ( A =[[2, 1, 3], [1, 2, 4], [4, 2, 3], [1, 1, 1]] ,
b =[12, 9, 13, 4],
c =[1,2,3])
visual = simplex_visual ( lp = lp )
visual.write_html ("2.html")
