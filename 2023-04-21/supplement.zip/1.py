from gilp import LP
from gilp import simplex_visual

lp = LP ( A =[[2, 1], [1, 2]] ,
b =[12, 9],
c =[1, 1])
visual = simplex_visual ( lp = lp )
visual.write_html ("1.html")
